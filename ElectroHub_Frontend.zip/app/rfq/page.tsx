import type { Metadata } from 'next';
import { GlobalLayout } from '@/components/layout/GlobalLayout';
import { RFQPageClient } from '@/components/rfq/RFQPageClient';

// ─── Metadata ─────────────────────────────────────────────────────────────────
export const metadata: Metadata = {
  title:       'Request a Quote | ElectroHub',
  description: 'Submit a Request For Quotation for electronics components, modules, and custom requirements. Our team will respond within 1–2 business days.',
  keywords:    ['rfq', 'request for quotation', 'bulk order', 'custom electronics', 'B2B', 'ElectroHub'],
};

// ─── Page ─────────────────────────────────────────────────────────────────────
export default function RFQPage() {
  return (
    <GlobalLayout>
      <RFQPageClient />
    </GlobalLayout>
  );
}
