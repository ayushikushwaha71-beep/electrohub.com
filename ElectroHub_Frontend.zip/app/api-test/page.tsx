"use client";

import { useEffect, useState } from "react";
import {
  getProducts,
  searchProducts,
  type BackendProduct,
} from "@/lib/products-api";

export default function ApiTestPage() {
  const [products, setProducts] = useState<BackendProduct[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function testAPI() {
      try {
        const data = await getProducts();

        console.log("PRODUCT API RESPONSE:", data);

        setProducts(data.results);
      } catch (err) {
        console.error(err);

        setError(
          err instanceof Error ? err.message : "API request failed"
        );
      } finally {
        setLoading(false);
      }
    }

    testAPI();
  }, []);

  if (loading) {
    return <div style={{ padding: 40 }}>Loading products...</div>;
  }

  if (error) {
    return (
      <div style={{ padding: 40 }}>
        <h1>API Error</h1>
        <p>{error}</p>
      </div>
    );
  }

  return (
    <div style={{ padding: 40 }}>
      <h1>ElectroHub API Test</h1>

      <p>
        Products received: <strong>{products.length}</strong>
      </p>

      {products.length === 0 ? (
        <p>No products found in database.</p>
      ) : (
        products.map((product) => (
          <div
            key={product.id}
            style={{
              border: "1px solid #ddd",
              padding: 20,
              marginTop: 15,
              borderRadius: 8,
            }}
          >
            <h2>{product.name}</h2>

            <p>SKU: {product.sku}</p>

            <p>Category: {product.category_name}</p>

            <p>Brand: {product.brand_name || "No Brand"}</p>

            <p>Price: ₹{product.final_price}</p>

            <p>Stock: {product.stock}</p>

            <p>
              Status: {product.status}
            </p>
          </div>
        ))
      )}
    </div>
  );
}