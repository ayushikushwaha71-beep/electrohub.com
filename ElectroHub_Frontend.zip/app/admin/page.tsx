import type { Metadata } from 'next';
import { GlobalLayout } from '@/components/layout/GlobalLayout';
import { AdminDashboard } from '@/components/admin/AdminDashboard';

export const metadata: Metadata = {
  title: 'Admin Dashboard — ElectroHub',
  description: 'ElectroHub admin dashboard overview for catalog, orders, users, and revenue analytics.',
  robots: { index: false, follow: false },
};

export default function AdminPage() {
  return (
    <GlobalLayout>
      <AdminDashboard />
    </GlobalLayout>
  );
}
